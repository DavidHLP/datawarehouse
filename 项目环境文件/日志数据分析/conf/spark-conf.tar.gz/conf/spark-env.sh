# Java和Hadoop相关环境变量
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export HADOOP_CONF_DIR=/opt/hadoop/etc/hadoop
export YARN_CONF_DIR=/opt/hadoop/etc/hadoop

# 设置 Spark Worker 和 Executor 使用的 Python 解释器
export PYSPARK_PYTHON=/opt/conda/envs/py38/bin/python

# 设置 Spark Driver 使用的 Python 解释器
export PYSPARK_DRIVER_PYTHON=/opt/conda/envs/py38/bin/python

# Spark Worker节点配置
export SPARK_WORKER_CORES=1
export SPARK_WORKER_MEMORY=1g
export SPARK_WORKER_PORT=7078
export SPARK_WORKER_WEBUI_PORT=8081

## 设置历史服务器
# 将Spark程序运行的历史日志存储到HDFS的/sparklog目录中
export SPARK_HISTORY_OPTS="-Dspark.history.fs.logDirectory=hdfs://mycluster/sparklog/ -Dspark.history.fs.cleaner.enabled=true"

# 启用Zookeeper来管理Master高可用性
export SPARK_DAEMON_JAVA_OPTS="-Dspark.deploy.recoveryMode=ZOOKEEPER \
-Dspark.deploy.zookeeper.url=zoo1:2181,zoo2:2181,zoo3:2181 \
-Dspark.deploy.zookeeper.dir=/spark"

# 设置 Worker 节点的默认 Master 地址
export SPARK_MASTER_URL="spark://hadoop-master1:7077,hadoop-master2:7077,hadoop-master3:7077"
