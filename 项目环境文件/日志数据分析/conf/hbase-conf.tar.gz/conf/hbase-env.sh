# Hadoop 相关的配置
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export HADOOP_HOME=/opt/hadoop
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_YARN_HOME=$HADOOP_HOME
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop  # 指向 Hadoop 配置目录
export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native:$LD_LIBRARY_PATH
export PATH=$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH

# HBase 相关的配置
export HBASE_HOME=/opt/hbase  # HBase 安装路径
export HBASE_CONF_DIR=$HBASE_HOME/conf
export PATH=$HBASE_HOME/bin:$PATH

# 禁用 HBase 自带的 Hadoop
# export HBASE_CLASSPATH=$HADOOP_CONF_DIR:$HADOOP_HOME/share/hadoop/common/lib/*:$HADOOP_HOME/share/hadoop/hdfs/*
export HBASE_DISABLE_HADOOP_CLASSPATH_LOOKUP="true"

# 指定 HADOOP_CLASSPATH，确保 HBase 能正确引用 Hadoop 配置和必要的 jar 文件
# export HADOOP_CLASSPATH=$HADOOP_CONF_DIR:$HADOOP_HOME/share/hadoop/common/lib/*:$HADOOP_HOME/share/hadoop/hdfs/*

# 配置 HBase 使用本地 Hadoop
# export HBASE_OPTS="$HBASE_OPTS -Dhadoop.home.dir=$HADOOP_HOME -Dhadoop.conf.dir=$HADOOP_CONF_DIR"

# 与 ZooKeeper 的集成配置
export HBASE_MANAGES_ZK=false  # 使用独立的 ZooKeeper 集群，不由 HBase 管理
